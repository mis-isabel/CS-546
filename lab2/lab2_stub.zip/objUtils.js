/* Todo: Implment the functions below and then export them
      using the ES6 exports syntax. 
      DO NOT CHANGE THE FUNCTION NAMES
*/

let solvePuzzles = (puzzles, pieces) => {};

let evaluatePokerHand = (hand, communityCards) => {};

let combineObjects = (arr) => {};
