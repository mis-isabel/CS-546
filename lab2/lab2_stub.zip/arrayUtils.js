/* Todo: Implment the functions below and then export them
      using the ES6 exports syntax. 
      DO NOT CHANGE THE FUNCTION NAMES
*/

let mergeCommonElements = (...args) => {
  //this function takes in a variable number of arrays that's what the ...args signifies
};

let findTriangles = (arr) => {};

let stringMetrics = (arr) => {};
