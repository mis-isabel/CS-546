// This data file should export all functions using the ES6 standard as shown in the lecture code

const createAttendee = async (eventId, firstName, lastName, emailAddress) => {
  //Implement Code here
};

const getAllAttendees = async (eventId) => {
  //Implement Code here
};

const getAttendee = async (attendeeId) => {
  //Implement Code here
};

const removeAttendee = async (attendeeId) => {
  //Implement Code here
};
