//Here is where you will do all of the logic and processing for the palindrome and prime checking.
