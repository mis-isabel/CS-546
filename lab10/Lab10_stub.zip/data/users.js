//import mongo collections, bcrypt and implement the following data functions
export const registerUser = async (
  firstName,
  lastName,
  emailAddress,
  password,
  role
) => {};

export const loginUser = async (emailAddress, password) => {};
