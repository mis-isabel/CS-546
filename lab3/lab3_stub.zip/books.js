//TODO EXPORT AND IMPLEMENT THE FOLLOWING FUNCTIONS IN ES6 FORMAT
//Books data link: https://gist.githubusercontent.com/graffixnyc/3381b3ba73c249bfcab1e44d836acb48/raw/e14678cd750a4c4a93614a33a840607dd83fdacc/books.json

const getBookById = async (id) => {};

const getAuthorName = async (bookId) => {};

const sameGenre = async (genre) => {};

const priceRange = async (min, max) => {};

const getAllBooksWithAuthorName = async () => {};
