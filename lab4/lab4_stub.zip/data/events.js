// TODO: Export and implement the following functions in ES6 format
const create = async (
  eventName, 
  eventDescription, 
  eventLocation, 
  contactEmail, 
  maxCapacity, 
  priceOfAdmission, 
  eventDate, 
  startTime, 
  endTime, 
  publicEvent
) => {};

const getAll = async () => {};

const get = async (id) => {};

const remove = async (id) => {};

const rename = async (id, newEventName) => {};
